import json
from audit_rl_sim import AuditEnv
from audit_rl_sim.env import SafeCalculator


def test_reset_is_reproducible():
    a = AuditEnv(); b = AuditEnv()
    oa, _ = a.reset(123); ob, _ = b.reset(123)
    assert oa == ob
    assert a.export_public() == b.export_public()
    assert a.export_closed() == b.export_closed()


def test_agent_observation_does_not_contain_truth():
    env = AuditEnv()
    obs, _ = env.reset(9)
    serialized = json.dumps(obs)
    assert "truth" not in serialized.lower()
    assert "provenance" not in serialized.lower()
    assert "issue_id" not in serialized.lower()


def test_pagination_limit_and_unknown_id():
    env = AuditEnv(); env.reset(1)
    obs, r, term, trunc, _ = env.step({"tool":"list_records","table":"ledger","limit":51})
    assert "error" in obs["result"]
    assert r == 0 and not term and not trunc
    obs, *_ = env.step({"tool":"get_record","table":"ledger","id":"NO-SUCH"})
    assert "error" in obs["result"]


def test_safe_calculator():
    assert SafeCalculator.calculate("(12.5 + 7.5) * 2") == "40.0"
    try:
        SafeCalculator.calculate("__import__('os').system('whoami')")
        assert False
    except ValueError:
        pass


def test_oracle_scores_perfectly():
    from audit_rl_sim.policies import OraclePolicy
    env = AuditEnv(); env.reset(17)
    action = OraclePolicy().act(env)
    _, reward, terminated, truncated, _ = env.step(action)
    assert terminated and not truncated
    assert env.evaluator_result()["f1"] == 1.0
    assert reward > 0.9


def test_clean_silence_beats_false_positive():
    from audit_rl_sim.policies import MarkAllPolicy
    env1 = AuditEnv(); env1.reset(22, {"clean": True})
    _, silence_reward, *_ = env1.step({"tool":"submit","findings":[]})
    env2 = AuditEnv(); env2.reset(22, {"clean": True})
    _, false_reward, *_ = env2.step(MarkAllPolicy().act(env2))
    assert silence_reward > false_reward


def test_duplicate_findings_do_not_increase_tp():
    from audit_rl_sim.policies import OraclePolicy
    env = AuditEnv(); env.reset(33, {"issue_types":["duplicate_invoice"]})
    action = OraclePolicy().act(env)
    one = action["findings"][0]
    action["findings"].append(dict(one))
    env.step(action)
    result = env.evaluator_result()
    assert result["tp"] == 1
    assert result["fp"] == 1


def test_max_steps_truncates():
    env = AuditEnv(); env.reset(4)
    result = None
    for _ in range(100):
        result = env.step({"tool":"calculator","expression":"1+1"})
    assert result[3] is True
    assert result[0]["result"] is None
