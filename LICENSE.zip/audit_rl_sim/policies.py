
"""Small baseline policies and offline runner helpers."""

from __future__ import annotations

import json
import random


class OraclePolicy:
    """Upper-bound policy for local evaluation only."""

    def act(self, env):
        truth = env.export_closed()["truth"]
        findings = []

        for issue in truth["issues"]:
            evidence = issue["acceptable_evidence_sets"][0]
            findings.append({
                "type": issue["type"],
                "affected_ids": issue["affected_ids"],
                "claimed_amount_minor": issue["expected_amount_minor"],
                "currency": issue["currency"],
                "evidence_ids": evidence,
                "explanation": "Matched the disclosed synthetic evidence set.",
            })

        return {"tool": "submit", "findings": findings}


class MarkAllPolicy:
    """Adversarial policy: accuse every invoice."""

    def act(self, env):
        findings = []

        for inv in env.tables["invoices"][:30]:
            findings.append({
                "type": "duplicate_invoice",
                "affected_ids": [inv["invoice_id"]],
                "claimed_amount_minor": int(inv["total_minor"]),
                "currency": inv["currency"],
                "evidence_ids": [inv["doc_id"]],
                "explanation": "Flagged by broad heuristic.",
            })

        return {"tool": "submit", "findings": findings}


class RandomInvestigator:
    """Randomly inspects records, then submits an empty report."""

    def __init__(self, seed=0):
        self.rng = random.Random(seed)

    def act(self, env):
        if env.steps >= 8:
            return {"tool": "submit", "findings": []}

        table = self.rng.choice(
            ["ledger", "invoices", "payments", "fx"]
        )

        return {
            "tool": "list_records",
            "table": table,
            "limit": 10,
        }


class ReconciliationPolicy:
    """Rule-based baseline using public episode tables."""

    def act(self, env):
        invoices = env.tables["invoices"]
        ledger = env.tables["ledger"]
        payments = env.tables["payments"]

        findings = []

        # 1. Search for duplicate invoices.
        groups = {}

        for inv in invoices:
            signature = (
                inv.get("entity_id"),
                inv.get("issued_at"),
                inv.get("currency"),
                inv.get("total_minor"),
                json.dumps(
                    inv.get("line_items", []),
                    sort_keys=True,
                ),
            )
            groups.setdefault(signature, []).append(inv)

        for group in groups.values():
            if len(group) < 2:
                continue

            first = group[0]

            for duplicate in group[1:]:
                duplicate_rows = [
                    row for row in ledger
                    if row.get("invoice_id") == duplicate.get("invoice_id")
                ]

                if not duplicate_rows:
                    continue

                findings.append({
                    "type": "duplicate_invoice",
                    "affected_ids": [
                        first["invoice_id"],
                        duplicate["invoice_id"],
                    ],
                    "claimed_amount_minor": int(first["total_minor"]),
                    "currency": first["currency"],
                    "evidence_ids": [
                        first["doc_id"],
                        duplicate["doc_id"],
                        duplicate_rows[0]["row_id"],
                    ],
                    "explanation": (
                        "Two invoices have matching supplier, date, "
                        "currency, amount and line items."
                    ),
                })

        # 2. Check invoice currency against accounts-payable ledger rows.
        for inv in invoices:
            matching_rows = [
                row for row in ledger
                if row.get("invoice_id") == inv.get("invoice_id")
                and row.get("account") == "Accounts Payable"
            ]

            for row in matching_rows:
                if row.get("currency") != inv.get("currency"):
                    findings.append({
                        "type": "wrong_fx",
                        "affected_ids": [
                            inv["invoice_id"],
                            row["row_id"],
                        ],
                        "claimed_amount_minor": int(inv["total_minor"]),
                        "currency": inv["currency"],
                        "evidence_ids": [
                            inv["doc_id"],
                            row["row_id"],
                        ],
                        "explanation": (
                            "Invoice currency differs from the "
                            "related accounts-payable ledger currency."
                        ),
                    })

        # 3. Check accounts-payable posting dates against the period.
        manifest = env.public["manifest.json"]
        period_start = manifest["period_start"]
        period_end = manifest["period_end"]

        for inv in invoices:
            matching_rows = [
                row for row in ledger
                if row.get("invoice_id") == inv.get("invoice_id")
                and row.get("account") == "Accounts Payable"
            ]

            for row in matching_rows:
                row_date = str(row.get("timestamp", ""))[:10]

                if row_date and not (
                    period_start <= row_date <= period_end
                ):
                    findings.append({
                        "type": "period_cutoff",
                        "affected_ids": [
                            row["row_id"],
                            inv["invoice_id"],
                        ],
                        "claimed_amount_minor": int(inv["total_minor"]),
                        "currency": inv["currency"],
                        "evidence_ids": [
                            inv["doc_id"],
                            row["row_id"],
                        ],
                        "explanation": (
                            "Accounts-payable posting date is outside "
                            "the reporting period."
                        ),
                    })

        # 4. Look for payments with missing invoice allocation.
        for payment in payments:
            if payment.get("invoice_refs"):
                continue

            payment_date = str(payment.get("timestamp", ""))[:10]
            amount = int(payment.get("amount_minor", 0))
            currency = payment.get("currency")

            candidates = []

            for inv in invoices:
                if inv.get("currency") != currency:
                    continue

                invoice_date = str(inv.get("issued_at", ""))[:10]
                due_date = str(inv.get("due_at", ""))[:10]
                invoice_amount = int(inv.get("total_minor", 0))

                if not (
                    invoice_date <= payment_date <= due_date
                ):
                    continue

                if amount not in (
                    invoice_amount,
                    invoice_amount // 2,
                ):
                    continue

                candidates.append(inv)

            # Report only when exactly one invoice is plausible.
            if len(candidates) == 1:
                inv = candidates[0]

                findings.append({
                    "type": "payment_allocation",
                    "affected_ids": [
                        payment["payment_id"],
                        inv["invoice_id"],
                    ],
                    "claimed_amount_minor": amount,
                    "currency": currency,
                    "evidence_ids": [
                        payment["doc_id"],
                        inv["doc_id"],
                    ],
                    "explanation": (
                        "Payment has no invoice allocation and matches "
                        "one plausible invoice by date, amount and currency."
                    ),
                })

        return {
            "tool": "submit",
            "findings": findings[:30],
        }


def run_policy(env, policy, seed=0, max_steps=100):
    obs, info = env.reset(seed=seed)
    trajectory = []

    for step_no in range(max_steps):
        action = policy.act(env)

        next_obs, reward, terminated, truncated, step_info = env.step(action)

        trajectory.append({
            "episode_id": (
                obs["manifest"]["episode_id"]
                if "manifest" in obs
                else f"ep-{seed:08d}"
            ),
            "step": step_no + 1,
            "action": action,
            "observation": next_obs,
            "reward": reward,
            "terminated": terminated,
            "truncated": truncated,
        })

        obs = next_obs

        if terminated or truncated:
            break

    return trajectory
