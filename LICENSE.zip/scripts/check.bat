@echo off
python -m pip install -e ".[dev]"
pytest -q
python -m audit_rl_sim.cli --seed 7 --policy oracle
